<?php
// WordPress view bootstrapper

define( 'WP_USE_THEMES', true );
require( './wordpress/wp-blog-header.php' );
