// -------------------------------------
//   Start Doc Ready
// -------------------------------------

jQuery(document).ready(function($) {
	
}); 
// -- End Doc Ready
